CORRECTION / PRIMARY REPORTED SYMPTOM: BRIGHTNESS INCREASE
The original selection showed darkening and did not match the operator report.
00-SDK-7.0.5-brightness-increase.png now leads the evidence page. It shows a saved
brightening event: sampled mean Y 69.5067 -> 75.9374 -> 69.5134, SDK 7.0.5.39292,
BT709_F requested, 1920x1080, SHM sequences 2364 / 2366 / 2368.
Captured samples are unchanged. The exact symptom match and active-speaker
causation remain unconfirmed. The darkening examples and earlier video are
additional findings and may have different causes. Do not equate them with the
reported brightening symptom.

CoreVideo Pro / Zoom Meeting SDK - intermittent video artifacts
Captured: 22 September 2026, Windows x64
Tracking: https://github.com/iamfatness/CoreVideoPro/issues/582

WHAT THE VIDEO SHOWS
This is a diagnostic replay assembled from actual captured before/flash/after
luma samples, not a continuous screen recording. Frames are held for two seconds
and repeated to make short artifacts visible. Replay duration is not event duration.
The samples are grayscale Y only, every eighth pixel in each direction: a
1920x1080 frame becomes 240x135 samples, enlarged with nearest-neighbor scaling.
No brightness adjustment, interpolation, or synthesized source frames were used.
The MP4 is H.264 encoded for easy sharing; the included NPZ arrays preserve the
exact captured samples. Probe sampling is not exhaustive.

CAPTURE BOUNDARY
Video frames came from the Zoom helper's shared-memory I420 output, after its
per-frame limited-to-full range normalization and before CoreVideo compositing/UI.
The probe copied only stable, even sequence-numbered publications. JSON includes
probe observation times and SHM sequence numbers; these are not SDK timestamps.

EXAMPLE A - CONTRAST SHIFT
Zoom Windows Meeting SDK 7.0.5.39292, requested BT709_F.
Full test: 120 seconds, 30,456 sampled frames, 10 isolated luma excursions.
Shown source: 1920x1080; SHM sequences 4774, 4776, 4778.
Mean sampled Y: 155.677 -> 150.709 -> 155.700.
Flash observation: 2026-09-22 12:05:46.718 UTC (probe clock).

EXAMPLE B - SEVERE DARK FRAME
Zoom Windows Meeting SDK 7.1.5.43953, requested BT709_L.
Helper compiled against matching SDK headers/import library; loaded sdk.dll
version verified. No luma instrumentation or hardware-setting changes in this
clean helper candidate. Existing range normalizer remained active.
Full repeat: 300 seconds, 88,932 sampled frames, one isolated dark frame.
Shown source: 1920x1080; SHM sequences 10298, 10300, 10302.
Mean sampled Y: 78.890 -> 5.295 -> 78.947.
Flash observation: 2026-09-22 12:35:28.552 UTC (probe clock).
The preceding instrumented five-minute run had zero detections in 92,616 samples;
the failed clean repeat is why this candidate was rejected.

ADDITIONAL SDK-CALLBACK EVIDENCE (SEPARATE CAPTURE)
A diagnostic sampler inside onRawDataFrameReceived compared the SDK's incoming
Y bytes with normalized output. Across one excursion, raw mean was 147.100 then
151.711; normalized mean was 152.657 then 157.730; preceding normalized mean
was 157.727. IsLimitedI420() was true on both sampled callback events. Thus that
excursion was already present in SDK callback input. This separate callback trace
is not a claim that Example B's exact frame has matching raw-input diagnostics.

OTHER COMPARISONS
- Requesting BT709_L with SDK 7.0.5 passed initial short runs, then failed a repeat.
- Disabling receiving hardware acceleration separately: 8 detected excursions
  in 29,827 samples over 120 seconds.
- Disabling processing hardware acceleration separately: 3 detected excursions
  in 24,471 samples over 120 seconds.
- SDK 7.1.5 with original BT709_F also reproduced a range-shaped excursion.
  That startup probe observed only two feeds and is not an eight-feed comparison.
- Original receiving/processing settings were restored enabled. No fix shipped.

WORKLOAD AND LIMITS
Eight camera subscriptions; all reached 1080p in the five-minute comparisons.
Streaming and recording were off; raw probes ran externally. No resolution
downgrade, brightness heuristic, or frame suppression was used.
Operator notices the quick flash in Preview/multiview around active-speaker
changes and has not noticed it in the ordinary Zoom client. A concurrent
179-snapshot trace observed four speaker changes and zero subscription churn.
This does not establish active-speaker causation. Sender content, SDK decoding,
SDK configuration, and conversion remain possible areas to isolate; the evidence
does not establish a vendor defect or prove both visual patterns share one cause.

REQUEST FOR SDK ENGINEERING
Please advise how to diagnose intermittent luma/range excursions and dark frames
at the Windows Meeting SDK raw-video boundary, especially when IsLimitedI420()
does not change. Recommended decoder/raw-data logging and a minimal reproduction
configuration would help. We can provide targeted additional captures.

PACKAGE CONTENTS
- CoreVideo-Zoom-SDK-flash-evidence.mp4: annotated replay
- README.txt: these technical notes
- frame-evidence.json: timestamps, sequences, statistics, original NPZ SHA-256
- Two NPZ files: exact before/flash/after sampled Y arrays

No meeting URL, passcode, authentication token, audio, or unfiltered application
log is included. The footage retains the visible content of the test feeds.
